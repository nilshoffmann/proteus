/**
 * 
 */
package maltcms.ui.viewer.datastructures.tree;

/**
 * @author Nils.Hoffmann@CeBiTec.Uni-Bielefeld.DE

 *
 */
public class ElementNotFoundException extends RuntimeException {

	/**
     * 
     */
    private static final long serialVersionUID = 7864374322427340984L;

}
