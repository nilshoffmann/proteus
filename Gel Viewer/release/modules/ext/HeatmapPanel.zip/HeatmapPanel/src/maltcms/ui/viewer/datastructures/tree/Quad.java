/**
 * 
 */
package maltcms.ui.viewer.datastructures.tree;

/**
 * @author Nils.Hoffmann@CeBiTec.Uni-Bielefeld.DE

 *
 */
public enum Quad {
	
		NW,NE,SE,SW;
	
}
