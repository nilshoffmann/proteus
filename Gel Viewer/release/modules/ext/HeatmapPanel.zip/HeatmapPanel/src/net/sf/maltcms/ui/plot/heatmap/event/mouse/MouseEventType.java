/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.sf.maltcms.ui.plot.heatmap.event.mouse;

/**
 *
 * @author nilshoffmann
 */
public enum MouseEventType {

    CLICKED,PRESSED,RELEASED,ENTERED,EXITED,DRAGGED,MOVED,WHEEL,NONE;
    
}
